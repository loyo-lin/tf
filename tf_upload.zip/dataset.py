import torch
import torch.nn as nn
from torch.utils.data import Dataset



class Bilingualdataset(Dataset):
    def __init__(self,ds,tokenizer_src,tokenizer_tgt,src_lang,tgt_lang,seq_len)->None:
        super().__init__()

        self.ds=ds
        self.tokenizer_src=tokenizer_src
        self.tokenizer_tgt=tokenizer_tgt
        self.src_lang=src_lang
        self.tgt_lang=tgt_lang
        self.seq_len=seq_len

        self.src_sos_token_id=tokenizer_src.token_to_id('[SOS]')
        self.src_eos_token_id=tokenizer_src.token_to_id('[EOS]')
        self.src_pad_token_id=tokenizer_src.token_to_id('[PAD]')
        self.tgt_sos_token_id=tokenizer_tgt.token_to_id('[SOS]')
        self.tgt_eos_token_id=tokenizer_tgt.token_to_id('[EOS]')
        self.tgt_pad_token_id=tokenizer_tgt.token_to_id('[PAD]')

    def __len__(self):
        return len(self.ds)

    def __getitem__(self, index):
        src_target_pair=self.ds[index]
        src_text=src_target_pair['translation'][self.src_lang]
        tgt_text=src_target_pair['translation'][self.tgt_lang]

        enc_input_tokens=self.tokenizer_src.encode(src_text).ids
        dec_input_tokens=self.tokenizer_tgt.encode(tgt_text).ids

        enc_num_padding_tokens=self.seq_len-len(enc_input_tokens)-2
        dec_num_padding_tokens=self.seq_len-len(dec_input_tokens)-1

        if enc_num_padding_tokens<0 or dec_num_padding_tokens<0:
            raise ValueError('Sentence is too long')

        encoder_input=torch.cat(
            [
                torch.tensor([self.src_sos_token_id],dtype=torch.int64),
                torch.tensor(enc_input_tokens,dtype=torch.int64),
                torch.tensor([self.src_eos_token_id],dtype=torch.int64),
                torch.full((enc_num_padding_tokens,),self.src_pad_token_id,dtype=torch.int64)
            ]
        )

        decoder_input=torch.cat(
            [
                torch.tensor([self.tgt_sos_token_id],dtype=torch.int64),
                torch.tensor(dec_input_tokens,dtype=torch.int64),
                torch.full((dec_num_padding_tokens,),self.tgt_pad_token_id,dtype=torch.int64)
            ]
        )

        label=torch.cat(
            [
                torch.tensor(dec_input_tokens,dtype=torch.int64),
                torch.tensor([self.tgt_eos_token_id],dtype=torch.int64),
                torch.full((dec_num_padding_tokens,),self.tgt_pad_token_id,dtype=torch.int64)
            ]
        )

        assert encoder_input.size(0)==self.seq_len
        assert decoder_input.size(0)==self.seq_len
        assert label.size(0)==self.seq_len

        return{
            "encoder_input":encoder_input,
            "decoder_input":decoder_input,
            "encoder_mask":(encoder_input!=self.src_pad_token_id).unsqueeze(0).unsqueeze(0).int(),
            "decoder_mask":(decoder_input!=self.tgt_pad_token_id).unsqueeze(0).unsqueeze(0).int() & causal_mask(decoder_input.size(0)),
            "label":label,
            "src_text":src_text,
            "tgt_text":tgt_text
        }

def causal_mask(size):
    mask=torch.triu(torch.ones(1,size,size),diagonal=1).type(torch.int)
    return mask==0
